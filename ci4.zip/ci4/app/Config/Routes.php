<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->resource('leads');
// $routes->post('create', 'Lead::create');

$routes->group('api/v1', static function ($routes) {
    $routes->post('create', 'Lead::create');
    $routes->get('create', 'Lead::create');
    $routes->get('blog', 'Admin\Blog::index');
});

