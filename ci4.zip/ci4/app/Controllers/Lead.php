<?php 
namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class Lead extends ResourceController
{
    use ResponseTrait;
    
    public function create() {

        $key = $this->request->getGetPost('key');
        $emailservice = $this->request->getGetPost('email');
        $excelservice = $this->request->getGetPost('excel');
        $name = $this->request->getVar('name');
        $email = $this->request->getVar('email');
        $mobile = $this->request->getVar('mobile');
        $source = $this->request->getVar('source');
        $pageurl = $this->request->getVar('pageurl');
        $project = $this->request->getVar('project');
        try {
            if($this->request->is('post')) {
                if(!empty($key)){
                    $flag = 0;
                    $excelurl ="";
                    foreach(project as $ky => $val){
                        if($key == $ky){
                            $flag = 1;
                            $excelurl = 'excel_'.$project;
                            break;
                        }
                    }
                    if($flag == 1){
                        $data = [
                            'name' => $this->request->getVar('name'),
                            'email'  => $this->request->getVar('email'),
                            'mobile'  => $this->request->getVar('mobile'),
                            'source'  => $this->request->getVar('source'),
                            'pageurl'  => $this->request->getVar('pageurl'),
                        ];
                        if($excelservice ==1){
                            $excel = $this->excel($excelurl, $data);
                            if(isset($excel) && $excel ==0){
                                $response = [
                                    'status'   => false,
                                    'statusCode'   => STATUS_407,
                                    'error'    => MSG_407,
                                    'messages' => [
                                        'success' => MSG_407
                                    ]
                                ];
                                return $this->respondCreated($response);
                            }else{
                                $response = [
                                    'status'   => true,
                                    'statusCode'   => STATUS_200,
                                    'error'    => null,
                                    'messages' => [
                                        'success' => MSG_200
                                    ]
                                ];
                                return $this->respondCreated($response);
                            }
                        }
                    }else{
                        $response = [
                            'status'   => false,
                            'statusCode'   => STATUS_407,
                            'error'    => MSG_407,
                            'messages' => [
                                'success' => null
                            ]
                        ];
                        $info = [
                            'project'   => $project,
                            'key'     => $key,
                        ];
                        
                        log_message('info', '{project} this project name is using for this key => {key}', $info);
                        return $this->respondCreated($response);
                    }
                }else{
                    $response = [
                        'status'   => false,
                        'statusCode'   => STATUS_405,
                        'error'    => MSG_405,
                        'messages' => [
                            'success' => null
                        ]
                    ];
                    return $this->respondCreated($response);
                }
            }else{
                $response = [
                    'status'   => false,
                    'statusCode'   => STATUS_406,
                    'error'    => MSG_406,
                    'messages' => [
                        'success' => null
                    ]
                ];
                return $this->respondCreated($response);
            }
        } catch (\Exception $e) {
            $response = [
                'status'   => false,
                'statusCode'   => STATUS_1000,
                'error'    => $e->getMessage(),
                'messages' => [
                    'success' => null
                ]
            ];
            return $this->respondCreated($response);
            exit($e->getMessage());
        }
        
    }

    public function excel($excelurl, $data){
        foreach(excel_link as $k => $v){
            $excelinsert = 0;
            if($k == $excelurl){
                $linkurl = $v;
                $excelinsert = 1;
                break;
            }
        }

        if($excelinsert == 1){
            $name = $data['name'];
            $email = $data['email'];
            $phone = $data['mobile'];
            $pageurl = $data['pageurl'];
            $urlpparam2 = $linkurl."?Name=".urlencode($name)."&Mobile=".$phone."&Email=".urlencode($email)."&URL=".urlencode($pageurl)."&DateTime=".urlencode(date("j F Y, g:i a"));
            $verify = curl_init();
            curl_setopt($verify, CURLOPT_URL, $urlpparam2);
            curl_setopt($verify, CURLOPT_POST, true);
            //curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($credential));
            curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($verify, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($verify, CURLOPT_RETURNTRANSFER, true);
            $responsecap = curl_exec($verify);
            $status= json_decode($responsecap, true);
            setcookie('excel', $responsecap, time() + (60 * 5), "/");
            setcookie('status', $status, time() + (60 * 60 * 5), "/");
            return $status;
        }else{
            $status = 0 ;
            return  $status;
        }
        
    }
}